-- MySQL dump 10.13  Distrib 5.1.69, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: u827911637_akvod
-- ------------------------------------------------------
-- Server version	5.1.69
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Administratori_table`
--

DROP TABLE IF EXISTS `Administratori_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Administratori_table` (
  `id_admina` int(11) NOT NULL AUTO_INCREMENT,
  `imya_admina` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `parol` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `e-mail` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `telephon` varchar(18) COLLATE utf8_unicode_ci NOT NULL,
  `uvedomlyat_na_telephon` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `uvedomlyat_na_email` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_admina`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Список администраторов и менеджеров';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Administratori_table`
--

LOCK TABLES `Administratori_table` WRITE;
/*!40000 ALTER TABLE `Administratori_table` DISABLE KEYS */;
INSERT INTO `Administratori_table` VALUES (1,'Максим','admin','tempos18','zinchenkomax@ukr.net','091-114-23-77','checked','checked');
/*!40000 ALTER TABLE `Administratori_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Novosti_table`
--

DROP TABLE IF EXISTS `Novosti_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Novosti_table` (
  `id_novosti` int(5) NOT NULL AUTO_INCREMENT,
  `data_vihoda_novosti` date NOT NULL,
  `nazvanie_novosti` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `anons_of_a_new` varchar(2450) COLLATE utf8_unicode_ci NOT NULL,
  `path_to_a_new` varchar(245) COLLATE utf8_unicode_ci NOT NULL,
  `opublikovana` int(11) NOT NULL,
  PRIMARY KEY (`id_novosti`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Таблица содержит список всех новостей';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Novosti_table`
--

LOCK TABLES `Novosti_table` WRITE;
/*!40000 ALTER TABLE `Novosti_table` DISABLE KEYS */;
INSERT INTO `Novosti_table` VALUES (42,'2028-10-20','Запущен сайт посвященный АКВОД','Сегодня состоялось открытие Интернет-ресурса, посвященного суперабсорбенту АКВОД.','arhiv_novostey/otkritie_saita_akvod/index.htm',1);
/*!40000 ALTER TABLE `Novosti_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Podpischiki_na_novosti_table`
--

DROP TABLE IF EXISTS `Podpischiki_na_novosti_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Podpischiki_na_novosti_table` (
  `id_podpischika` int(11) NOT NULL AUTO_INCREMENT,
  `e-mail_podpischika` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_podpischika`),
  UNIQUE KEY `e-mail_podpischika` (`e-mail_podpischika`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Список е-мэйлов подписанных на новости';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Podpischiki_na_novosti_table`
--

LOCK TABLES `Podpischiki_na_novosti_table` WRITE;
/*!40000 ALTER TABLE `Podpischiki_na_novosti_table` DISABLE KEYS */;
INSERT INTO `Podpischiki_na_novosti_table` VALUES (21,'maksphoto3@hotmail.com'),(20,'shmelin@ya.ru');
/*!40000 ALTER TABLE `Podpischiki_na_novosti_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pokupateli_table`
--

DROP TABLE IF EXISTS `Pokupateli_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pokupateli_table` (
  `id_pokupatelya` int(11) NOT NULL AUTO_INCREMENT,
  `naimenovanie_pokupatelya` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `telephon` varchar(18) COLLATE utf8_unicode_ci NOT NULL,
  `email_via_login` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `parol_k_uchetnoi_zapisi` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `data_registratsii` date NOT NULL,
  PRIMARY KEY (`id_pokupatelya`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Содержит список покупателей';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pokupateli_table`
--

LOCK TABLES `Pokupateli_table` WRITE;
/*!40000 ALTER TABLE `Pokupateli_table` DISABLE KEYS */;
INSERT INTO `Pokupateli_table` VALUES (72,'Maksim','093-','','','2013-09-05'),(71,'Maksim','093-','','','2013-09-05'),(70,'Максим','1234','ermijad@inbox.ru','123','2013-09-03'),(69,'s','s','','','2013-09-03'),(67,'s','s','','','2013-09-03'),(68,'s','s','','','2013-09-03'),(65,'s','s','','','2013-09-03'),(66,'s','s','','','2013-09-03'),(63,'s','s','','','2013-09-03'),(64,'s','s','','','2013-09-03'),(62,'s','s','shmelin@ukr.net','1','2013-09-03'),(61,'s','s','shmelin@yandex.ru','1','2013-09-03'),(60,'s','s','shmelin@mail.ru','1','2013-09-03'),(59,'Максим Перепелица','23-77','shmelin@ya.ru','qwerty','2013-09-02'),(58,'Максим','39-44','','','2013-09-02'),(57,'','','','','2013-09-02'),(56,'Maksim','-537','shmelin@ya.ru','tempos','2013-09-01'),(73,'Paromschik','23','akvod@ukr.net','tempos','2013-09-23'),(75,'Максим','091-114-23-77','','','2013-09-27'),(76,'Максим Укртелеком','091-114-23-77','M.Zinchenko@ukrtelecom.ua','tempos','2013-09-27'),(77,'w','w','','','2013-10-27'),(78,'к','к','','','2013-10-28'),(79,'к','к','','','2013-10-28'),(80,'к','к','','','2013-10-28'),(81,'к','к','','','2013-10-28'),(82,'Максим','093-466-89-75','','','2013-10-30'),(83,'Максим','093-466-89-75','maksphoto3@hotmail.com','tempos','2013-10-30'),(84,'вавава','3333333333','','','2013-11-04'),(85,'вавава','3333333333','','','2013-11-04'),(86,'вавава','3333333333','','','2013-11-04'),(87,'вавава','3333333333','','','2013-11-04');
/*!40000 ALTER TABLE `Pokupateli_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Punkti_menu_adminki_table`
--

DROP TABLE IF EXISTS `Punkti_menu_adminki_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Punkti_menu_adminki_table` (
  `nomer_punkta_menu` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Номер пункта меню',
  `nazvanie_punkta_menu` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Название пункта меню',
  `podskazka_k_punktu` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Подсказка к пункту меню',
  `link_na_script` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Ссылка на целевой скрипт',
  PRIMARY KEY (`nomer_punkta_menu`),
  UNIQUE KEY `nazvanie_punkta_menu` (`nazvanie_punkta_menu`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Таблица содержит доступные пункты меню админ-части';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Punkti_menu_adminki_table`
--

LOCK TABLES `Punkti_menu_adminki_table` WRITE;
/*!40000 ALTER TABLE `Punkti_menu_adminki_table` DISABLE KEYS */;
INSERT INTO `Punkti_menu_adminki_table` VALUES (1,'Сменить пароль менеджера','Сменить пароль менеджера','/admin/smenit_parol/index.php'),(6,'Оповещения','Настройки оповещения менеджера о новом заказе','/admin/opovescheniya/index.php'),(3,'Заказы','Просмотр заказов по фильтрам','/admin/zakazi/index.php'),(4,'Товары','Редактирование товаров','/admin/tovari/index.php'),(5,'Новости','Управление новостями','/admin/novosti/index.php'),(2,'Покупатели','Список зарегистрированных покупателей','/admin/pokupateli/index.php');
/*!40000 ALTER TABLE `Punkti_menu_adminki_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sostav_zakaza_table`
--

DROP TABLE IF EXISTS `Sostav_zakaza_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sostav_zakaza_table` (
  `id_zapisi_sostava` int(11) NOT NULL AUTO_INCREMENT,
  `id_zakaza` int(11) NOT NULL,
  `id_tovara` int(11) NOT NULL,
  `kolichestvo_shtuk_tovara_v_zakaze` int(11) NOT NULL,
  PRIMARY KEY (`id_zapisi_sostava`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Содержит перечень товаров и их количество для каждого заказа';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sostav_zakaza_table`
--

LOCK TABLES `Sostav_zakaza_table` WRITE;
/*!40000 ALTER TABLE `Sostav_zakaza_table` DISABLE KEYS */;
INSERT INTO `Sostav_zakaza_table` VALUES (88,56,3,1),(87,56,2,2),(86,56,1,1),(85,55,3,2),(84,55,4,1),(83,55,2,2),(82,55,1,1),(81,54,3,1),(80,54,2,1),(79,54,1,1),(78,53,4,1),(77,53,3,1),(76,53,2,13),(75,53,1,14),(74,52,1,1),(73,71,1,1),(72,51,3,1),(71,51,1,4),(70,47,1,1),(69,46,1,1),(68,44,1,2),(67,43,1,1),(66,42,1,1),(65,41,1,1),(64,40,1,1),(63,39,1,1),(62,38,1,1),(61,57,1,1),(60,37,1,1),(89,57,1,5),(90,57,4,46),(91,57,2,2),(92,57,3,2),(93,58,1,1),(94,59,1,1),(95,60,1,1),(96,61,1,1),(97,62,1,1),(98,64,1,1),(99,66,1,1),(100,67,1,6),(101,67,2,2),(102,67,4,1),(103,68,1,1),(104,69,1,1),(105,70,1,1),(106,72,1,1);
/*!40000 ALTER TABLE `Sostav_zakaza_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sposobi_dostavki_table`
--

DROP TABLE IF EXISTS `Sposobi_dostavki_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sposobi_dostavki_table` (
  `id_sposoba_dostavki` int(11) NOT NULL AUTO_INCREMENT,
  `naimenovanie_sposoba_dostavki` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `opisanie_sposoba_dostavki` varchar(1045) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_sposoba_dostavki`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='содержир список доступных способов доставки';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sposobi_dostavki_table`
--

LOCK TABLES `Sposobi_dostavki_table` WRITE;
/*!40000 ALTER TABLE `Sposobi_dostavki_table` DISABLE KEYS */;
INSERT INTO `Sposobi_dostavki_table` VALUES (3,'Самовывоз со склада','Стоимость такой доставки -- Бесплатно. Забрать можно на нашем складе по адресу г.Киев, ул.Горького 40'),(2,'Курьер к дверям','Стоимость доставки по г. Киеву 2 грн/кг (min 30 грн)'),(4,'Новой Почтой по Украине','Стоимость доставки вы можете уточнить у оператора Новой Почты по номеру (044) 323-02-22 в Киеве или на <a href=\'http://novaposhta.ua/frontend/currier\' target=\"_blank\">этой странице</a>');
/*!40000 ALTER TABLE `Sposobi_dostavki_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sposobi_oplati_table`
--

DROP TABLE IF EXISTS `Sposobi_oplati_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sposobi_oplati_table` (
  `id_sposoba_oplati` int(11) NOT NULL AUTO_INCREMENT,
  `naimenovanie_sposoba_oplati` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `opisanie_sposoba_oplati` varchar(1045) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_sposoba_oplati`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Содердит доступные способы оплаты';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sposobi_oplati_table`
--

LOCK TABLES `Sposobi_oplati_table` WRITE;
/*!40000 ALTER TABLE `Sposobi_oplati_table` DISABLE KEYS */;
INSERT INTO `Sposobi_oplati_table` VALUES (1,'Предоплата 100% по безналу',''),(2,'Наличными курьеру',''),(3,'Наложенным платежом Новая Почта','');
/*!40000 ALTER TABLE `Sposobi_oplati_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tovari_table`
--

DROP TABLE IF EXISTS `Tovari_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tovari_table` (
  `id_tovara` int(11) NOT NULL AUTO_INCREMENT,
  `nazvanie_tovara` varchar(245) COLLATE utf8_unicode_ci NOT NULL,
  `link_na_small_kartinku` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `tsena` float NOT NULL,
  `nalichie_na_sklade` tinyint(1) NOT NULL,
  `opisanie_tovara` varchar(2045) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_tovara`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Содержит информацию о доступных товарах';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tovari_table`
--

LOCK TABLES `Tovari_table` WRITE;
/*!40000 ALTER TABLE `Tovari_table` DISABLE KEYS */;
INSERT INTO `Tovari_table` VALUES (1,'АКВОД 10г (100шт в упаковке) гранула 1мм','akvod_10g.png',360,1,'Почвенный аккумулятор влаги АКВОД, гранулы диаметром 1мм. Расфасован в бумажные пакеты по 10 г. Минимальный заказ одна упаковка. В упаковке 100 пакетов. Вес упаковки 1 кг. Упаковка полиэтиленовая. Цена за упаковку.'),(2,'АКВОД 30г (100шт в упаковке) гранула 1мм','akvod_30g.png',900,1,'Почвенный аккумулятор влаги АКВОД, гранулы диаметром 1мм. Расфасован в бумажные пакеты по 30 г. Минимальный заказ одна упаковка. В упаковке 100 пакетов. Вес упаковки 3 кг. Упаковка полиэтиленовая. Цена за упаковку.'),(3,'АКВОД 50г (100шт в упаковке) гранула 1мм','akvod_50g.png',1500,1,'Почвенный аккумулятор влаги АКВОД, гранулы диаметром 1мм. Расфасован в бумажные пакеты по 50 г. Минимальный заказ одна упаковка. В упаковке 100 пакетов. Вес упаковки 5 кг. Упаковка полиэтиленовая. Цена за упаковку.'),(4,'АКВОД 800г (10шт в упаковке) гранула 1мм','akvod_800g.png',1300,1,'Почвенный аккумулятор влаги АКВОД, гранулы диаметром 1мм. Расфасован в пластиковые ведерки по 800 г. Минимальный заказ одна упаковка. В упаковке 10 ведерок. Вес упаковки 8 кг. Упаковка полиэтиленовая. Цена за упаковку.'),(6,'АКВОД 25кг (мешок) гранула 1мм','akvod_25kg.png',3350,1,'Почвенный аккумулятор влаги АКВОД, гранулы диаметром 1мм. Расфасован в полипропиленовые мешки по 25 кг. Минимальный заказ один мешок.  Цена за мешок.');
/*!40000 ALTER TABLE `Tovari_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vozmozhnie_statusi_zakaza_table`
--

DROP TABLE IF EXISTS `Vozmozhnie_statusi_zakaza_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vozmozhnie_statusi_zakaza_table` (
  `id_statusa` int(11) NOT NULL AUTO_INCREMENT,
  `naimenovanie_statusa` varchar(145) COLLATE utf8_unicode_ci NOT NULL,
  `opisanie_statusa` varchar(1045) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_statusa`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='содержит список возможных статусов заказа';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vozmozhnie_statusi_zakaza_table`
--

LOCK TABLES `Vozmozhnie_statusi_zakaza_table` WRITE;
/*!40000 ALTER TABLE `Vozmozhnie_statusi_zakaza_table` DISABLE KEYS */;
INSERT INTO `Vozmozhnie_statusi_zakaza_table` VALUES (1,'Добавлен',''),(2,'Проведен',''),(3,'На доставку',''),(4,'Завершен',''),(5,'Отменен',''),(6,'Ожидает покупателя на складе','');
/*!40000 ALTER TABLE `Vozmozhnie_statusi_zakaza_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Zakazi_table`
--

DROP TABLE IF EXISTS `Zakazi_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Zakazi_table` (
  `id_zakaza` int(11) NOT NULL AUTO_INCREMENT,
  `id_pokupatelya` int(11) NOT NULL,
  `id_sposoba_dostavki` int(11) NOT NULL,
  `adress_dostavki` varchar(450) COLLATE utf8_unicode_ci NOT NULL,
  `id_sposoba_oplati` int(11) NOT NULL,
  `id_statusa_zakaza` int(11) NOT NULL,
  `primechanie_k_zakazu` varchar(1045) COLLATE utf8_unicode_ci NOT NULL,
  `data_zakaza` date NOT NULL,
  PRIMARY KEY (`id_zakaza`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Содержит список всех заказов';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Zakazi_table`
--

LOCK TABLES `Zakazi_table` WRITE;
/*!40000 ALTER TABLE `Zakazi_table` DISABLE KEYS */;
INSERT INTO `Zakazi_table` VALUES (51,70,3,'КИев',1,1,' ','0000-00-00'),(50,69,2,'s',1,1,' ','0000-00-00'),(47,66,2,'s',1,1,' ','0000-00-00'),(48,67,2,'s',1,1,' ','0000-00-00'),(45,64,2,'s',1,1,' ','0000-00-00'),(46,65,2,'s',1,2,' ','0000-00-00'),(42,62,2,'s',1,1,' ','0000-00-00'),(43,56,2,'s',1,1,' ','0000-00-00'),(44,63,2,'s',1,1,' ','0000-00-00'),(41,61,2,'s',1,1,' ','0000-00-00'),(40,60,2,'s',1,1,' ','0000-00-00'),(39,59,3,'Kiev',2,1,'Проверяю отправку е-мэйла. Перевод строки.','0000-00-00'),(38,58,2,'Киев',2,2,' повторно без создания учетной записи','0000-00-00'),(37,56,3,'Kiev',1,1,'проверяю $dannie_o_polz ','0000-00-00'),(52,72,2,'КИев',1,1,' ','2013-09-05'),(53,56,3,'КИев',2,1,' ','2013-09-05'),(54,56,3,'КИев',2,2,' Изменено на айпад','2013-09-05'),(55,56,3,'weere',2,3,'Изменяю комментарий к заказу через форму редактирования статуса заказа','2013-09-05'),(56,56,3,'s',2,1,' ','2013-09-05'),(57,74,2,'23',2,1,' ','2013-09-23'),(58,56,2,'23',2,1,' ','2013-09-23'),(59,75,3,'Киев хата',3,1,' Добавлено в айпад ','2013-09-27'),(60,76,3,'Киев хата',3,1,' Добавлено в айпад ','2013-09-27'),(61,77,3,'w',2,1,' w','2013-10-27'),(62,78,2,'к',1,1,' ','2013-10-28'),(63,79,2,'к',1,1,' ','2013-10-28'),(64,80,2,'к',1,1,' ','2013-10-28'),(65,81,2,'к',1,1,' ','2013-10-28'),(66,56,2,'к',1,1,' ','2013-10-28'),(67,82,3,'КИев',1,1,' Хаджя','2013-10-30'),(68,83,3,'КИев',1,1,' Хаджя','2013-10-30'),(69,84,2,'вава',2,1,' ','2013-11-04'),(70,85,2,'вава',2,1,' ','2013-11-04'),(71,86,2,'вава',2,1,' ','2013-11-04'),(72,87,2,'вава',2,2,'','2013-11-04');
/*!40000 ALTER TABLE `Zakazi_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-11-06 15:09:17
